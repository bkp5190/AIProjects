# qlearningAgents.py
# ------------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from game import *
from learningAgents import ReinforcementAgent
from featureExtractors import *

import random,util,math

class QLearningAgent(ReinforcementAgent):
    """
      Q-Learning Agent

      Functions you should fill in:
        - computeValueFromQValues
        - computeActionFromQValues
        - getQValue
        - getAction
        - update

      Instance variables you have access to
        - self.epsilon (exploration prob)
        - self.alpha (learning rate)
        - self.discount (discount rate)

      Functions you should use
        - self.getLegalActions(state)
          which returns legal actions for a state
    """
    def __init__(self, **args):
        "You can initialize Q-values here..."
        ReinforcementAgent.__init__(self, **args)

        "*** YOUR CODE HERE ***"
        # I begin by initializing a "Counter" defined in util as a dictionary to keep track of the q values
        self.q = util.Counter()

    def getQValue(self, state, action):
        """
          Returns Q(state,action)
          Should return 0.0 if we have never seen a state
          or the Q node value otherwise
        """
        "*** YOUR CODE HERE ***"
        # This function can simply return the initialized Q value function from before because it will return the Q node value
        return self.q[(state, action)]

    def computeValueFromQValues(self, state):
        """
          Returns max_action Q(state,action)
          where the max is over legal actions.  Note that if
          there are no legal actions, which is the case at the
          terminal state, you should return a value of 0.0.
        """
        "*** YOUR CODE HERE ***"
        # I begin by creating a new "Counter" type to not only keep track of the q values, but also to utilize its .argMax() functionality. I
        # then iterate through all the legl actions after checking the no legal actions case. Within this loop, I use the new counter to hold all
        # the computed Q node values and then finally return the maximum.
        newCount = util.Counter()
        legalActions = self.getLegalActions(state)
        if len(legalActions) == 0:
          return 0.0
        for action in legalActions:
          newCount[action] = self.getQValue(state, action)
        
        maximum = newCount.argMax()
        return newCount[maximum]

    def computeActionFromQValues(self, state):
        """
          Compute the best action to take in a state.  Note that if there
          are no legal actions, which is the case at the terminal state,
          you should return None.
        """
        "*** YOUR CODE HERE ***"
        # Similar to computeValueFromQValues, I iterate through the legal actions after checking the no legal actions case. Within this loop, I 
        # compare computed q values until I find the best and set the best action as well.
        legalActions = self.getLegalActions(state)
        best = None
        compare = -9999999
        for action in legalActions:
          q = self.q[(state, action)]
          if compare < q:
            compare = q
            best = action
        return best

    def getAction(self, state):
        """
          Compute the action to take in the current state.  With
          probability self.epsilon, we should take a random action and
          take the best policy action otherwise.  Note that if there are
          no legal actions, which is the case at the terminal state, you
          should choose None as the action.

          HINT: You might want to use util.flipCoin(prob)
          HINT: To pick randomly from a list, use random.choice(list)
        """
        # Pick Action
        legalActions = self.getLegalActions(state)
        action = None
        "*** YOUR CODE HERE ***"
        # I began by declaring the correct probability that needs to be utilized in the flipCoin() function as given by the hint.
        # Then, in order to pick and action, I just check the return of flipCoin and either randomly select from the legal actions
        # list as given by the hint or take the best policy.
        prob = self.epsilon
        choice = util.flipCoin(prob)
        if choice == True:
          return random.choice(legalActions)
        else:
          return self.getPolicy(state)

        return action

    def update(self, state, action, nextState, reward):
        """
          The parent class calls this to observe a
          state = action => nextState and reward transition.
          You should do your Q-Value update here

          NOTE: You should never call this function,
          it will be called on your behalf
        """
        "*** YOUR CODE HERE ***"
        # I began the update function by first calculating the old q values by using the getQValue function. I also use alpha to calculate the correct reward.
        # after getting these values, I check if it is the next state or not and set values as needed. When it is the next state, the first set of parentheses
        # holds the value of the previous q value, the second parentheses is the reward, and the final is the value of the next q. Similarly, if the next
        # state is not encountered then only the q value + the reward is set.

        alpha = self.alpha
        discount = self.discount
        reciprocal = 1 - self.alpha

        if nextState:
          self.q[(state, action)] = (reciprocal * self.getQValue(state, action)) + (alpha * reward) + (alpha * discount * self.getValue(nextState))
        else:
          self.q[(state, action)] = (reciprocal * self.getQValue(state, action)) + (alpha * reward)

    def getPolicy(self, state):
        return self.computeActionFromQValues(state)

    def getValue(self, state):
        return self.computeValueFromQValues(state)


class PacmanQAgent(QLearningAgent):
    "Exactly the same as QLearningAgent, but with different default parameters"

    def __init__(self, epsilon=0.05,gamma=0.8,alpha=0.2, numTraining=0, **args):
        """
        These default parameters can be changed from the pacman.py command line.
        For example, to change the exploration rate, try:
            python pacman.py -p PacmanQLearningAgent -a epsilon=0.1

        alpha    - learning rate
        epsilon  - exploration rate
        gamma    - discount factor
        numTraining - number of training episodes, i.e. no learning after these many episodes
        """
        args['epsilon'] = epsilon
        args['gamma'] = gamma
        args['alpha'] = alpha
        args['numTraining'] = numTraining
        self.index = 0  # This is always Pacman
        QLearningAgent.__init__(self, **args)

    def getAction(self, state):
        """
        Simply calls the getAction method of QLearningAgent and then
        informs parent of action for Pacman.  Do not change or remove this
        method.
        """
        action = QLearningAgent.getAction(self,state)
        self.doAction(state,action)
        return action


class ApproximateQAgent(PacmanQAgent):
    """
       ApproximateQLearningAgent

       You should only have to overwrite getQValue
       and update.  All other QLearningAgent functions
       should work as is.
    """
    def __init__(self, extractor='IdentityExtractor', **args):
        self.featExtractor = util.lookup(extractor, globals())()
        PacmanQAgent.__init__(self, **args)
        self.weights = util.Counter()

    def getWeights(self):
        return self.weights

    def getQValue(self, state, action):
        """
          Should return Q(state,action) = w * featureVector
          where * is the dotProduct operator
        """
        "*** YOUR CODE HERE ***"
        # In order to compute the dot product of the weights and the featureVector, I had to begin the function by finding the featureVector with
        # the first line. Next, I created a variable to hold the final return value and iterate through each value in the vector and add the
        # values from the dot product as I iterate through both accordingly.
        featureVector = self.featExtractor.getFeatures(state, action)

        product = 0
        for feature in featureVector:
          product += featureVector[feature] * self.getWeights()[feature]
        return product

    def update(self, state, action, nextState, reward):
        """
           Should update your weights based on transition
        """
        "*** YOUR CODE HERE ***"
        # Similar to the last function, I set a variable to hold the featureVector again. Additionally, I calculate the transition function for 
        # updating the weights within the loop.
        alpha = self.alpha
        discount = self.discount
        featureVector = self.featExtractor.getFeatures(state, action)

        trasition = (reward + self.getValue(nextState) * discount) - self.getQValue(state, action)

        for feature in featureVector:
          self.getWeights()[feature] = alpha * trasition * featureVector[feature] + self.getWeights()[feature]

    def final(self, state):
        "Called at the end of each game."
        # call the super-class final method
        PacmanQAgent.final(self, state)

        # did we finish training?
        if self.episodesSoFar == self.numTraining:
            # you might want to print your weights here for debugging
            "*** YOUR CODE HERE ***"
            # I added a simple for loop to iterate through the feature vector and print the weights.
            for feature in featureVector:
              print(feature)
              print(self.weights[feature])
