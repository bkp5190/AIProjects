import math

def f(x):
	return (math.exp(x) + x -7)

def secant(x0, x1):
	return (x1 - (f(x)*(x1-x0)/f(x1)-f(x0)))


x0 = 1
x1 = 2
tol = 0.001
x2 = secant(x0, x1)
print(x2)
x3 = secant(x1, x2)
print(x3)