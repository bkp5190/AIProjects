import numpy as np
matrix = np.zeros([100, 100])

counter = 0

for i in matrix:
	matrix[counter][counter] = 2
	matrix[counter][counter+1] = -1
	matrix[counter+1][counter] = -1
	counter += 1
	if counter = 99:
		break

print(matrix)
